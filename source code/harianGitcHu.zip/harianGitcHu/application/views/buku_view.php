<div> 
		<p align="center"><img src="<?=base_url().'uploads/'.$buku->cover;?>" width='100%' height='100%'/></p>
</div>
<?php 
if($buku_row != null ){
	foreach ($buku_row as $row) { ?>  
	<div> 
	<div id="isibuku">
		<h3><?php echo $row->title; ?></h3>
		<p><?php echo $row->content; ?></p>
	</div>
		<div id="comment">
	 <?php
	       $attributes = array('id' => 'FormComment'.$row->id_content);
			echo form_open_multipart('utama/insert_comment',$attributes);  
			echo form_hidden('id_content',$row->id_content); 
		?>
			<fieldset>
				<label>Comment</label>
				<textarea rows="5" name='comment' class='comment'></textarea>
			</fieldset>
			<input type="submit" name="category" value="Masukkin" class="alt_btn">
			<?php echo form_close(); ?>
	 </div>
	
	</div>
<?php 

echo '
<script type="text/javascript">
$(document).ready(function() {
       $("#FormComment'.$row->id_content.'").submit(function(event){
	    event.preventDefault(); 
          $.post( 
             "utama/insert_comment",
             $("#FormComment'.$row->id_content.'").serialize(),
             function(data) {
                alert("Komentar Sukses Dimasukkin");
             }

          );
      });
   });
</script>	';				 
?>	     
			
<?php
}

echo "<div> 
		<p align='center'>To be Continued.............</p>
	  </div>";
}
else{
	echo "	<div> 
			<h3>Belum Ada Judul</h3>
			<p>MaCih kosong Gan,Diisi Donk..!</p>
			</div>";
}
?>


<script type="text/javascript">
	$(function() {
	//single book
	$('#mybook').booklet({
	width:790,
	height:800,
	closed: true,
	autoCenter: true
	});
	});

</script>


	
