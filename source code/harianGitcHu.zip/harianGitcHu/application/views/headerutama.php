<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8"/>
	<title>Situs Utama Cin kkkkkkkkkkk</title>
	
	<link rel="stylesheet" href="<?=base_url()?>css/layout.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?=base_url()?>css/jquery-ui.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?=base_url()?>css/jquery.timepicker.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?=base_url()?>css/jquery.booklet.1.4.0.css" type="text/css" media="screen" />
	
	
	<!--[if lt IE 9]>
	<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen" />
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<script src="<?=base_url()?>js/jquery-1.7.2.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>js/jquery-ui-1.8.21.custom.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>js/jquery.timepicker.js" type="text/javascript"></script>
	<script src="<?=base_url()?>js/jquery.booklet.1.4.0.min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>js/jquery.easing.1.3.js" type="text/javascript"></script>
	<script src="<?=base_url()?>js/hideshow.js" type="text/javascript"></script>
	<script src="<?=base_url()?>js/jquery.tablesorter.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="<?=base_url()?>js/jquery.equalHeight.js"></script>
	
 	

</head>


<body onload="onload()">

	<header id="header">
		<hgroup>
			<h1 class="site_title"><a href="<?=base_url()?>">Buku Harian</a></h1>
			<h2 class="section_title">Diaryku</h2><div class="btn_view_site"><a href="http://www.medialoot.com">NDaShboard</a></div>
		</hgroup>
	</header> <!-- end of header bar -->
	
	<section id="secondary_bar">
		<div class="user">
			<p>John Doe (<a href="#">3 Messages</a>)</p>
			<!-- <a class="logout_user" href="#" title="Logout">Logout</a> -->
		</div>
		<div class="breadcrumbs_container">
			<article class="breadcrumbs"><a href="index.html">Buku Harianku</a> <div class="breadcrumb_divider"></div> <a class="current">Dashboard</a></article>
		</div>
	</section><!-- end of secondary bar -->
	

	<aside id="sidebar" class="column">
	
		
	</aside><!-- end of sidebar -->
