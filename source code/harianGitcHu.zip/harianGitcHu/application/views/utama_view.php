
	
	<section id="main" class="column" >	
		
		
	
		
			<div class="clear"></div>
			</div>
		<!--content manager -->
		<article class="module width_3_quarter">
		<header>
		<h3 class="tabs_involved">List Diaryku</h3>
		
		</header>

		<div class="tab_container">
			
			<table class="tablesorter" cellspacing="0"> 
			
				<?php 
			    if($utama_row != null ){
				foreach ($utama_row as $row) { ?>  
				<tr> 
    				<td><img src='<?=base_url().'uploads/'.$row->cover;?>' width='80' height='100' class="cover" title="<?php echo $row->id_bukuharian;?>"/></td> 
				</tr> 
				<?php  
       }  
	   }
	   else{
				echo "<tr> 
    				<td>List Buku Harianku masih kosong T.T</td> 
    				
				</tr> ";
		}
	
       ?> 
			
			</table>
			
			</div>
		
		</article>
		<div class="clear"></div>
		
<article class="module width_full">
<header><h3>Bukuku</h3></header>
<div class="module_content">
		
<div id="mybook">


</div>
</article>
</section>	

<script type="text/javascript">
  $(document).ready(function() {
      $(".cover").click(function(event){
          $.post( 
             "utama/lihat_buku",
             { id_bukuharian: $(this).attr("title") },
             function(data) {
                $('#mybook').html(data);
             }

          );
      });
   });
</script>



	

